#ifndef ACTION_H_
#define ACTION_H_

class Action {
public:
    virtual void run() = 0;
};

#endif
