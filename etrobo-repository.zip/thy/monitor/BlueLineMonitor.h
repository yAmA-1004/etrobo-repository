#include "Monitor.cpp"
#include "Device.h"

class BlueLineMonitor : public Monitor {
public:
    BlueLineMonitor();
    bool check();
};
