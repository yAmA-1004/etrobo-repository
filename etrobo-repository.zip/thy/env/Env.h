#ifndef ENV_H_
#define ENV_H_

class Env {
public:
    static int course;
    static int white_r;
    static int white_g;
    static int white_b;
    static int black_r;
    static int black_g;
    static int black_b;
    static int block_pattern;
    static bool red_block_found;
};

#endif
